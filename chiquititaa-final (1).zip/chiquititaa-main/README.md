# Website Chiquititaa + database opini (Supabase)

Website ini menggunakan Supabase untuk menyimpan opini pengunjung. File `admin.html` menyediakan halaman login untuk melihat data.

## Cara menghubungkan database
1. Buat project di https://supabase.com/.
2. Buka `supabase-setup.sql`, ganti `admin@contoh.com` dengan email admin yang akan dipakai, lalu jalankan seluruh SQL di **SQL Editor**.
3. Buka **Project Settings → API** (atau API Keys) dan salin Project URL serta anon/public key.
4. Isi `config.js`:
   - `SUPABASE_URL` dengan Project URL.
   - `SUPABASE_ANON_KEY` dengan anon/public key.
   Jangan pernah menaruh `service_role` key di file frontend.
5. Di Supabase buka **Authentication → Users**, lalu tambahkan akun admin dengan email dan password.
6. Upload semua file website ke hosting yang mendukung file statis (atau jalankan server lokal). Buka `opinion.html` untuk mengirim opini dan `admin.html` untuk login serta melihat data.

## Penting tentang keamanan
Kebijakan SQL membatasi pembacaan opini berdasarkan email admin yang Anda masukkan. Pastikan email di SQL sama persis dengan email akun admin Supabase. Jangan gunakan data sensitif pada formulir publik.

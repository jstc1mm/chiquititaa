/* Form opini website — penyimpanan menggunakan Supabase. */
const supabaseReady = window.SUPABASE_URL &&
  window.SUPABASE_ANON_KEY &&
  !window.SUPABASE_URL.startsWith('ISI_') &&
  !window.SUPABASE_ANON_KEY.startsWith('ISI_');

const db = supabaseReady
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY)
  : null;

function showSetupMessage() {
  const pesan = document.getElementById('pesan');
  if (pesan) pesan.textContent = 'Database belum dikonfigurasi. Isi URL dan anon key Supabase di config.js terlebih dahulu.';
}

// Polling sederhana di halaman ini hanya untuk interaksi langsung; opini dikirim ke database.
window.pilih = function (jawaban) {
  const hasil = document.getElementById('hasil');
  if (hasil) hasil.textContent = `Pilihan kamu: ${jawaban}. Terima kasih!`;
};

const form = document.getElementById('formOpini');
if (form) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const pesan = document.getElementById('pesan');
    const submitButton = form.querySelector('button[type="submit"]');
    if (!db) { showSetupMessage(); return; }

    const nama = document.getElementById('nama').value.trim();
    const pilihan = document.getElementById('pilihan').value;
    const pendapat = document.getElementById('pendapat').value.trim();
    if (!nama || !pilihan || !pendapat) {
      pesan.textContent = 'Mohon lengkapi semua kolom.';
      return;
    }

    submitButton.disabled = true;
    pesan.textContent = 'Mengirim opini...';
    const { error } = await db.from('opinions').insert([{ nama, pilihan, pendapat }]);
    submitButton.disabled = false;

    if (error) {
      console.error(error);
      pesan.textContent = 'Opini belum berhasil disimpan. Periksa konfigurasi database atau coba lagi.';
      return;
    }
    form.reset();
    pesan.textContent = 'Opini berhasil dikirim dan tersimpan. Terima kasih!';
  });
}

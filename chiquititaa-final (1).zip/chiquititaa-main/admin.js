const configured = window.SUPABASE_URL && window.SUPABASE_ANON_KEY &&
  !window.SUPABASE_URL.startsWith('ISI_') && !window.SUPABASE_ANON_KEY.startsWith('ISI_');
const adminDb = configured ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY) : null;
const statusEl = document.getElementById('status');
const loginSection = document.getElementById('loginSection');
const dataSection = document.getElementById('dataSection');
const bodyEl = document.getElementById('opinionsBody');

function status(message) { statusEl.textContent = message; }
function showLoggedIn(loggedIn) {
  loginSection.classList.toggle('hidden', loggedIn);
  dataSection.classList.toggle('hidden', !loggedIn);
}
function cell(text) {
  const td = document.createElement('td');
  td.textContent = text == null ? '' : String(text);
  return td;
}
async function loadOpinions() {
  if (!adminDb) { status('Database belum dikonfigurasi. Isi config.js terlebih dahulu.'); return; }
  status('Memuat data...');
  const { data, error } = await adminDb.from('opinions')
    .select('id, nama, pilihan, pendapat, created_at')
    .order('created_at', { ascending: false });
  if (error) {
    console.error(error);
    status('Data gagal dimuat. Pastikan Anda login dan kebijakan RLS sudah dipasang.');
    return;
  }
  bodyEl.replaceChildren();
  if (!data.length) {
    const tr = document.createElement('tr');
    const td = cell('Belum ada opini yang masuk.'); td.colSpan = 4; tr.appendChild(td); bodyEl.appendChild(tr);
  } else {
    data.forEach((item) => {
      const tr = document.createElement('tr');
      const date = item.created_at ? new Date(item.created_at).toLocaleString('id-ID') : '';
      tr.append(cell(date), cell(item.nama), cell(item.pilihan), cell(item.pendapat));
      bodyEl.appendChild(tr);
    });
  }
  document.getElementById('summary').textContent = `Jumlah opini: ${data.length}`;
  status('Data berhasil dimuat.');
}

document.getElementById('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!adminDb) { status('Database belum dikonfigurasi. Isi config.js terlebih dahulu.'); return; }
  status('Memeriksa akun...');
  const { error } = await adminDb.auth.signInWithPassword({
    email: document.getElementById('email').value.trim(),
    password: document.getElementById('password').value
  });
  if (error) { status('Login gagal. Periksa email dan password admin.'); return; }
  showLoggedIn(true);
  await loadOpinions();
});
document.getElementById('refreshButton').addEventListener('click', loadOpinions);
document.getElementById('logoutButton').addEventListener('click', async () => {
  if (adminDb) await adminDb.auth.signOut();
  showLoggedIn(false); status('Anda sudah keluar.');
});

(async () => {
  if (!adminDb) { status('Database belum dikonfigurasi. Isi URL dan anon key Supabase di config.js.'); return; }
  const { data } = await adminDb.auth.getSession();
  if (data.session) { showLoggedIn(true); await loadOpinions(); }
})();

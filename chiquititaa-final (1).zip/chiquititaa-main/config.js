// Supabase connection for Chiquititaa.
// Safe to expose the publishable/anon key in a frontend site.
// Never put a service_role/secret key here.
window.SUPABASE_URL = 'https://dtwoabelxsnedqxznpam.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_RkzuOr0tLRQbqI0i56oJzQ_27rdSGdu';
